package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import models.CarDetails;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CarValuationPage {

    private WebDriver driver;

    private By regField = By.id("vehicleReg");
    private By mileageField = By.id("Mileage");
    private By valuationButton = By.id("btn-go");
    private By manufacturer = By.xpath("(//div[@class='d-table-cell value'])[1]");
    private By carModel = By.xpath("(//div[@class='d-table-cell value'])[2]");
    private By carYear = By.xpath("(//div[@class='d-table-cell value'])[3]");
    

    public CarValuationPage(WebDriver driver) {
        this.driver = driver;
    }

    public List<CarDetails> fetchValuations(List<String> regNumbers) {
        List<CarDetails> carDetailsList = new ArrayList<>();

        for (String reg : regNumbers) {
            driver.findElement(regField).sendKeys(reg);
            driver.findElement(mileageField).sendKeys("50000");
            driver.findElement(valuationButton).click();
            
            WebElement make = driver.findElement(manufacturer);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String carMake = (String) js.executeScript("return arguments[0].textContent;", make);
            
            WebElement model = driver.findElement(carModel);
            String carModel = (String) js.executeScript("return arguments[0].textContent;", model);
            
            WebElement year = driver.findElement(carYear);
            String carYear = (String) js.executeScript("return arguments[0].textContent;", year);
            
            CarDetails carDetails = new CarDetails(reg, carMake, carModel, carYear);
            carDetailsList.add(carDetails);
          
            //driver.findElement(regField).clear();
            //driver.findElement(mileageField).clear();
        }

        return carDetailsList;
    }
}
