package stepdefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.CarValuationPage;
import util.FileReader;
//import util.ValidationUtil;
import models.CarDetails; 
import java.util.List;
//import java.util.Map;

public class CarSteps {
	
	 	private WebDriver driver;
	    private CarValuationPage carValuationPage;
	    private List<String> registrationNumbers;
	    private List<CarDetails> actualValues;

	    @Given("I have a file {string} with car registration numbers")
	    public void iHaveAFileWithCarRegistrationNumbers(String inputFilePath) throws Exception {
	        registrationNumbers = FileReader.extractRegistrationNumbers(FileReader.readLines(inputFilePath));
	    }

	    @When("I fetch car value from {string}")
	    public void iFetchCarValuationsFromTheWebsite(String website) {
	        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.get("https://www.webuyanycar.com/");

	        carValuationPage = new CarValuationPage(driver);
	        actualValues = carValuationPage.fetchValuations(registrationNumbers);
	        driver.quit();
	    }

	    @Then("the value of the car should match the expected result in {string}")
	    public void theValuationsShouldMatchTheExpectedResults(String outputFilePath) throws Exception {
	        //Map<String, String> expectedValues = ValidationUtil.readExpectedValues(outputFilePath);
	        //ValidationUtil.validateResults(actualValues, expectedValues);
	    }
    

}
