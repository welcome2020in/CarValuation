package util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FileReader {
   
    public static List<String> readLines(String filePath) throws IOException {
    	filePath="C:\\JAVA Workspace\\car-valuation-suite\\src\\test\\resources\\car_input.txt";
        return Files.readAllLines(Paths.get(filePath));
    }

    public static List<String> extractRegistrationNumbers(List<String> lines) {
        List<String> registrationNumbers = new ArrayList<>();
        String pattern = "[A-Z]{2}\\d{2}\\s?[A-Z]{3}";

        for (String line : lines) {
            String[] words = line.split("\\s+");
            for (String word : words) {
                if (word.matches(pattern)) {
                    registrationNumbers.add(word);
                }
            }
        }

        return registrationNumbers;
    }
}
